#include "../Task 2/Graph_Task_2.cpp"
#include <functional> 
#include <unordered_set>






#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <memory>
#include <limits>
#include <algorithm>
#include <functional>







template <class T>
vector<shared_ptr<Vertex<T>>> Graph<T>::shortestPath(shared_ptr<Vertex<T>> source, shared_ptr<Vertex<T>> destination) {
    if (!source || !destination) {
        return {};
    }

    if (source == destination) {
        return {source};
    }

    if (vertices.empty() || edges.empty()) {
        return {};
    }

    if (weighted) {
        vector<int> distances(vertices.size(), INT_MAX);
        vector<shared_ptr<Vertex<T>>> parent(vertices.size(), nullptr);
        vector<bool> visited(vertices.size(), false);

        vector<shared_ptr<Vertex<T>>> vertexList;
        for (int i = 0; i < vertices.size(); ++i) {
            vertexList.push_back(vertices[i]);
        }

        int sourceIndex = -1;
        for (int i = 0; i < vertexList.size(); ++i) {
            if (vertexList[i] == source) {
                sourceIndex = i;
                break;
            }
        }

        distances[sourceIndex] = 0;

        queue<int> toVisit;
        toVisit.push(sourceIndex);

        while (!toVisit.empty()) {
            int currentIndex = toVisit.front();
            toVisit.pop();

            shared_ptr<Vertex<T>> currentVertex = vertexList[currentIndex];
            if (visited[currentIndex]) continue;

            visited[currentIndex] = true;

            vector<shared_ptr<Edge<T>>> edgesList = getEdges(currentVertex);
            for (int i = 0; i < edgesList.size(); ++i) {
                shared_ptr<Vertex<T>> neighbor = edgesList[i]->getDestination();
                int weight = edgesList[i]->getWeight();

                int neighborIndex = -1;
                for (int j = 0; j < vertexList.size(); ++j) {
                    if (vertexList[j] == neighbor) {
                        neighborIndex = j;
                        break;
                    }
                }

                int newDistance = distances[currentIndex] + weight;

                if (!visited[neighborIndex] && newDistance < distances[neighborIndex]) {
                    distances[neighborIndex] = newDistance;
                    parent[neighborIndex] = currentVertex;
                    toVisit.push(neighborIndex);
                }
            }
        }

        vector<shared_ptr<Vertex<T>>> path;
        int currentIndex = -1;
        for (int i = 0; i < vertexList.size(); ++i) {
            if (vertexList[i] == destination) {
                currentIndex = i;
                break;
            }
        }

        while (currentIndex != -1) {
            path.push_back(vertexList[currentIndex]);
            int prevIndex = -1;
            for (int i = 0; i < vertexList.size(); ++i) {
                if (vertexList[i] == parent[currentIndex]) {
                    prevIndex = i;
                    break;
                }
            }
            currentIndex = prevIndex;
            if (currentIndex == sourceIndex) break;
        }

        int pathSize = path.size();
        for (int i = 0; i < pathSize / 2; ++i) {
            swap(path[i], path[pathSize - i - 1]);
        }

        if (!path.empty() && path[path.size() - 1] == destination) {
            return path;
        }
    }

    return {}; 
}
template <class T>
vector<shared_ptr<Vertex<T>>> Graph<T>::topologicalSort() {
    if (!directed) {
        return {};
    }

    vector<int> inDegree(vertices.size(), 0);
    vector<shared_ptr<Vertex<T>>> vertexList;
    
    for (int i = 0; i < vertices.size(); ++i) {
        vertexList.push_back(vertices[i]);
    }

    for (int i = 0; i < edges.size(); ++i) {
        shared_ptr<Vertex<T>> destination = edges[i]->getDestination();
        int destinationIndex = -1;

        for (int j = 0; j < vertexList.size(); ++j) {
            if (vertexList[j] == destination) {
                destinationIndex = j;
                break;
            }
        }

        if (destinationIndex != -1) {
            inDegree[destinationIndex]++;
        }
    }

    // Queue for V with in-degree 0
    queue<int> q;
    for (int i = 0; i < vertexList.size(); ++i) {
        if (inDegree[i] == 0) {
            q.push(i);
        }
    }

    vector<shared_ptr<Vertex<T>>> result;

    // topological sort
    while (!q.empty()) {
        int currentIndex = q.front();
        q.pop();
        
        result.push_back(vertexList[currentIndex]);

        // Get adjacent vertices and decrease their in-degree
        vector<shared_ptr<Vertex<T>>> adjVertices = getAdjacentVertices(vertexList[currentIndex]);
        for (int i = 0; i < adjVertices.size(); ++i) {
            int adjIndex = -1;

            for (int j = 0; j < vertexList.size(); ++j) {
                if (vertexList[j] == adjVertices[i]) {
                    adjIndex = j;
                    break;
                }
            }

            if (adjIndex != -1) {
                inDegree[adjIndex]--;
                if (inDegree[adjIndex] == 0) {
                    q.push(adjIndex);
                }
            }
        }
    }

    if (result.size() != vertices.size()) {
        return {}; 
    }

    return result;
}

template <class T>
shared_ptr<Graph<T>> Graph<T>::minimumSpanningTree() {
    if (!isWeighted()) {
        return nullptr;
    }

    auto mst = make_shared<Graph<T>>(false, true); 

    vector<shared_ptr<Edge<T>>> edgeList = getAllEdges();
    vector<pair<int, pair<shared_ptr<Vertex<T>>, shared_ptr<Vertex<T>>>>> edges; 
    
    for (int i = 0; i < edgeList.size(); ++i) {
        edges.push_back({edgeList[i]->getWeight(), {edgeList[i]->getSource(), edgeList[i]->getDestination()}});
    }

    sort(edges.begin(), edges.end(), [](const auto &a, const auto &b) {
        return a.first < b.first;
    });

    // Union-Find
    int n = vertices.size();
    vector<int> parent(n), rank(n, 0);

    for (int i = 0; i < n; ++i) {
        parent[i] = i;
    }

    // Find the parent 
    function<int(int)> findParent = [&](int vertex) -> int {
        if (parent[vertex] != vertex) {
            parent[vertex] = findParent(parent[vertex]); 
        }
        return parent[vertex];
    };

    // Union by rank
    auto unionVertices = [&](int u, int v) {
        int rootU = findParent(u);
        int rootV = findParent(v);

        if (rootU != rootV) {
            if (rank[rootU] > rank[rootV]) {
                parent[rootV] = rootU;
            } else if (rank[rootU] < rank[rootV]) {
                parent[rootU] = rootV;
            } else {
                parent[rootV] = rootU;
                rank[rootU]++;
            }
        }
    };

    // Add V to the MST
    for (int i = 0; i < n; ++i) {
        mst->addVertex(vertices[i]->getData());
    }

    for (auto &[weight, edge] : edges) {
        shared_ptr<Vertex<T>> u = edge.first;
        shared_ptr<Vertex<T>> v = edge.second;

        int uIndex = -1, vIndex = -1;
        for (int i = 0; i < vertices.size(); ++i) {
            if (vertices[i] == u) uIndex = i;
            if (vertices[i] == v) vIndex = i;
        }

        if (findParent(uIndex) != findParent(vIndex)) {
            mst->addEdge(u->getData(), v->getData(), weight);
            unionVertices(uIndex, vIndex);
        }
    }

    return mst;
}

template <class T>
vector<vector<shared_ptr<Vertex<T>>>> Graph<T>::stronglyConnectedComponents() {
    vector<vector<shared_ptr<Vertex<T>>>> scc;

    int n = vertices.size();
    vector<bool> visited(n, false); 
    vector<shared_ptr<Vertex<T>>> finishOrder;

    for (int i = 0; i < n; ++i) {
        if (!visited[i]) {
            vector<shared_ptr<Vertex<T>>> traversal = DFSTraversal(vertices[i]);
            for (auto& v : traversal) {
                finishOrder.push_back(v);
            }
        }
    }

    vector<bool> visitedReversed(n, false); 
    for (int i = finishOrder.size() - 1; i >= 0; --i) {
        shared_ptr<Vertex<T>> vertex = finishOrder[i];
        int idx = -1;
        for (int j = 0; j < n; ++j) {
            if (vertices[j] == vertex) {
                idx = j;
                break;
            }
        }

        if (!visitedReversed[idx]) {
            vector<shared_ptr<Vertex<T>>> component = DFSTraversalReversed(vertex);
            scc.push_back(component);
        }
    }

    return scc;
}


// ::::::::::::::::::::::::::::::: BONUS TASKS :::::::::::::::::::::::::::::::::::

// BONUS TASK 1 FOR 5 MARKS
template <class T>
vector<shared_ptr<Graph<T>>> Graph<T>::SpanningTrees() {
    vector<shared_ptr<Graph<T>>> spanningTrees;
    
    vector<bool> visited(vertices.size(), false);
    
    for (auto vertex : vertices) {
        int idx = -1;
        for (int i = 0; i < vertices.size(); ++i) {
            if (vertices[i] == vertex) {
                idx = i;
                break;
            }
        }

        if (!visited[idx]) {
            shared_ptr<Graph<T>> tree = make_shared<Graph<T>>();
            stack<shared_ptr<Vertex<T>>> toVisit;
            toVisit.push(vertex);
            visited[idx] = true;

            while (!toVisit.empty()) {
                shared_ptr<Vertex<T>> current = toVisit.top();
                toVisit.pop();
                tree->addVertex(current->getData());

                vector<shared_ptr<Vertex<T>>> adjacentVertices = this->getAdjacentVertices(current);
                for (auto& neighbor : adjacentVertices) {
                    int neighborIdx = -1;
                    for (int i = 0; i < vertices.size(); ++i) {
                        if (vertices[i] == neighbor) {
                            neighborIdx = i;
                            break;
                        }
                    }
                    if (!visited[neighborIdx]) {
                        tree->addEdge(current->getData(), neighbor->getData());
                        visited[neighborIdx] = true;
                        toVisit.push(neighbor);
                    }
                }
            }
            spanningTrees.push_back(tree);
        }
    }

    return spanningTrees;
}



// BONUS TASK 2 FOR 5 MARKS

template <class T>
vector<vector<shared_ptr<Vertex<T>>>> Graph<T>::connectedComponents() {
    // Find all the connected components of the graph
    // A connected component is a set of vertices where each vertex is reachable from any other vertex in the same set
    // Return the connected components as a vector of vectors of vertices

    // Solution:
    vector<vector<shared_ptr<Vertex<T>>>> components;
    unordered_set<shared_ptr<Vertex<T>>> visited;

    for (auto vertex : vertices) {
        if (visited.find(vertex) == visited.end()) {
            // Perform DFS to find all vertices in the same component
            vector<shared_ptr<Vertex<T>>> component;
            stack<shared_ptr<Vertex<T>>> toVisit;
            toVisit.push(vertex);

            while (!toVisit.empty()) {
                auto currentVertex = toVisit.top();
                toVisit.pop();

                if (visited.find(currentVertex) == visited.end()) {
                    visited.insert(currentVertex);
                    component.push_back(currentVertex);

                    // Visit all adjacent vertices
                    for (auto adjVertex : getAdjacentVertices(currentVertex)) {
                        if (visited.find(adjVertex) == visited.end()) {
                            toVisit.push(adjVertex);
                        }
                    }
                }
            }

            components.push_back(component);
        }
    }

    return components;
}









template <class T>
vector<shared_ptr<Vertex<T>>> Graph<T>::DFSTraversalReversed(shared_ptr<Vertex<T>> vertex) {
    vector<shared_ptr<Vertex<T>>> visitedVertices;
    if (!vertex) return visitedVertices;

    stack<shared_ptr<Vertex<T>>> toVisit;
    vector<shared_ptr<Vertex<T>>> visited;

    toVisit.push(vertex);

    while (!toVisit.empty()) {
        shared_ptr<Vertex<T>> current = toVisit.top();
        toVisit.pop();

        bool alreadyVisited = false;
        for (auto& v : visited) {
            if (v == current) {
                alreadyVisited = true;
                break;
            }
        }

        if (!alreadyVisited) {
            visited.push_back(current);
            visitedVertices.push_back(current);

            // Get in-adjacent vertices (reversed edges)
            vector<shared_ptr<Vertex<T>>> adjacentVertices = getInAdjacentVertices(current);
            for (auto& neighbor : adjacentVertices) {
                toVisit.push(neighbor);
            }
        }
    }

    return visitedVertices;
}


